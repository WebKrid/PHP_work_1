 <?php
 $name = readline("Как тебя зовут ");
 $age = readline('Сколько тебе лет ');
 echo "Привет Вас зовут $name и вам $age лет";